 $(document).ready(function () {
        yourFunction();
    });
function yourFunction(){
$(".preload").fadeOut("slow");;

}

