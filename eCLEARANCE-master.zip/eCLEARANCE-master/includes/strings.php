<?php 

//SITE NAME - sn 
$sn = "TUK online clearance";
//SITE SLOGAN - ss
$ss = "fast,easy and convenient";
//DEFAULT COLOR  -dc
$dc = "default-color";
//DEFAULT COLOT HEX - if custom(not in MDB)
$dchex = "#C5A665";
//SECOND COLOR
$secondhex = "#0072bb";
//THIRD COLOR
$hex3 = "#0072BB";
//MAINBACKGROUND COLOR
$mainbg = "white";
//SITELOGO  -  Name in the images/logo folder
$slogo = "tuk.png";
//SITEICON - Name in the images/logo folder
$sicon = "tuk.png";
//CARD BG - Landing cards background
$cardbg = "tuk.png";
//LOGIN
$login = "LOGIN";
//REGISTER
$register = "REGISTER";
//ABOUT US
$about = "ABOUT US";
//CONTACT US
$contact = "CONTACT US";
//FAQ
$faq = "FAQ";
//WRITE TO US
$writetous = "WRITE TO US";
//CONTACT INFORMATION
$contactinfo = "CONTACT INFORMATION";
//SERVER NAME
$server = "localhost";
//DATABASE NAM
$dbname = "eclearance";
//DATABASE USERNAME
$dbuser = "root";
//DATABASE PASSWORD
$dbpass = NULL;







?>